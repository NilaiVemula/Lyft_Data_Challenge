# Lyft_Data_Challenge
A submission for the 2019 Lyft Data Challenge by Nilai Vemula and Terry Luo

Project Started on September 9, 2019

Project Submitted on September 15, 2019

# Folders: 

`/reports`: `.html` notebooks generated from the `.Rmd` analysis scripts

`/plots`: plots used in the final write-up

`/data`: ancillary `.csv` files created during the analysis process

